# Player Situational Profiles — 2025 season

For each player: the game situations where they **succeed** (high percentile vs positional peers) and where they **struggle** (low percentile). Built from FantasyPoints, PFF, and FTN charting data. Percentiles are within position among players clearing volume thresholds. Trend = year-over-year change in the headline efficiency metric (YPRR / elusiveness / pass grade).


## Quarterbacks (37)

**Matthew Stafford** (LAR) — PassGrade 73.3→91.7 ▲  
&nbsp;&nbsp;✓ Excels: Big-time throw rate (100th), Overall passing grade (100th), Play-action grade (100th), Avg depth of target (97th), Deep ball grade (97th)  
&nbsp;&nbsp;✗ Struggles: Time to throw (19th), Accuracy % (22nd)  

**Joe Burrow** (CIN) — PassGrade 92.9→91.3 ▼  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (100th), Under pressure (grade) (100th), Overall passing grade (97th), vs Blitz (YPA) (94th), Big-time throw rate (92nd)  
&nbsp;&nbsp;✗ Struggles: Play-action (YPA) (14th), Time to throw (28th), Under pressure (YPA) (28th), Pressure-to-sack rate (lower=better) (33rd), Deep ball accuracy % (33rd)  

**Jordan Love** (GB) — PassGrade 74.3→88.7 ▲  
&nbsp;&nbsp;✓ Excels: Clean pocket (YPA) (97th), Overall passing grade (94th), Pressure-to-sack rate (lower=better) (92nd), Big-time throw rate (89th), Avg depth of target (83rd)  
&nbsp;&nbsp;✗ Struggles: Under pressure (YPA) (6th)  

**Dak Prescott** (DAL) — PassGrade 67.2→85.4 ▲  
&nbsp;&nbsp;✓ Excels: Under pressure (grade) (97th), vs Blitz (YPA) (97th), Under pressure (YPA) (94th), Overall passing grade (92nd), Play-action grade (89th)  
&nbsp;&nbsp;✗ Struggles: Time to throw (31st)  

**Josh Allen** (BUF) — PassGrade 84.1→84.0 ▼  
&nbsp;&nbsp;✓ Excels: Under pressure (YPA) (92nd), Accuracy % (89th), Overall passing grade (89th), Under pressure (grade) (86th), Turnover-worthy play rate (lower=better) (83rd)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (33rd)  

**Brock Purdy** (SF) — PassGrade 76.3→82.6 ▲  
&nbsp;&nbsp;✓ Excels: Pressure-to-sack rate (lower=better) (100th), Deep ball accuracy % (97th), Accuracy % (94th), Time to throw (94th), Under pressure (grade) (94th)  
&nbsp;&nbsp;✗ Struggles: Deep ball grade (6th), Under pressure (YPA) (17th), Turnover-worthy play rate (lower=better) (22nd)  

**Trevor Lawrence** (JAX) — PassGrade 73.8→80.5 ▲  
&nbsp;&nbsp;✓ Excels: Under pressure (grade) (92nd), Avg depth of target (86th), Overall passing grade (83rd), vs Blitz (YPA) (83rd), Under pressure (YPA) (72nd)  
&nbsp;&nbsp;✗ Struggles: Turnover-worthy play rate (lower=better) (33rd), Accuracy % (33rd)  

**Sam Darnold** (SEA) — PassGrade 77.5→79.9 ▲  
&nbsp;&nbsp;✓ Excels: Clean pocket (YPA) (100th), Play-action (YPA) (97th), Play-action grade (97th), Deep ball accuracy % (94th), vs Blitz (YPA) (91st)  
&nbsp;&nbsp;✗ Struggles: Time to throw (22nd)  

**Jared Goff** (DET) — PassGrade 76.3→76.8 ▲  
&nbsp;&nbsp;✓ Excels: Accuracy % (100th), Turnover-worthy play rate (lower=better) (92nd), Deep ball accuracy % (88th), Play-action (YPA) (86th), Under pressure (YPA) (83rd)  
&nbsp;&nbsp;✗ Struggles: Time to throw (3rd), Big-time throw rate (6th), Avg depth of target (8th), Deep ball grade (24th)  

**Jalen Hurts** (PHI) — PassGrade 71.0→76.7 ▲  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (89th), Avg depth of target (81st), Time to throw (78th), Overall passing grade (75th), Under pressure (grade) (69th)  
&nbsp;&nbsp;✗ Struggles: Deep ball accuracy % (18th), vs Blitz (YPA) (26th), Play-action (YPA) (33rd)  

**Drake Maye** (NE) — PassGrade 64.9→76.6 ▲  
&nbsp;&nbsp;✓ Excels: Under pressure (YPA) (100th), Play-action (YPA) (94th), Deep ball grade (94th), Avg depth of target (92nd), Play-action grade (92nd)  
&nbsp;&nbsp;✗ Struggles: Pressure-to-sack rate (lower=better) (11th)  

**Bo Nix** (DEN) — PassGrade 73.8→76.1 ▲  
&nbsp;&nbsp;✓ Excels: Pressure-to-sack rate (lower=better) (97th), Deep ball grade (82nd), Big-time throw rate (75th), Deep ball accuracy % (70th), Overall passing grade (69th)  
&nbsp;&nbsp;✗ Struggles: Under pressure (YPA) (3rd), Play-action (YPA) (19th), vs Blitz (YPA) (23rd), Play-action grade (25th), Clean pocket (YPA) (29th)  

**Mac Jones** (SF) — PassGrade 62.1→75.4 ▲  
&nbsp;&nbsp;✓ Excels: Accuracy % (97th), Play-action grade (86th), Clean pocket (YPA) (76th), Play-action (YPA) (72nd), Overall passing grade (67th)  
&nbsp;&nbsp;✗ Struggles: Big-time throw rate (3rd), Under pressure (YPA) (8th), vs Blitz (YPA) (9th), Deep ball grade (9th), Time to throw (14th)  

**Kirk Cousins** (LV) — PassGrade 72.3→75.0 ▲  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (94th), Play-action (YPA) (89th), Pressure-to-sack rate (lower=better) (81st), Under pressure (grade) (78th), Play-action grade (69th)  
&nbsp;&nbsp;✗ Struggles: Deep ball accuracy % (3rd), Time to throw (6th), Clean pocket (YPA) (6th), Deep ball grade (15th), Avg depth of target (19th)  

**Jayden Daniels** (WAS) — PassGrade 84.7→73.8 ▼  
&nbsp;&nbsp;✓ Excels: Time to throw (81st), Big-time throw rate (72nd), Under pressure (YPA) (69th)  
&nbsp;&nbsp;✗ Struggles: vs Blitz (YPA) (0th), Clean pocket (YPA) (15th), Under pressure (grade) (25th), Play-action (YPA) (28th)  

**Tyler Shough** (NO)  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (86th), Accuracy % (67th), Avg depth of target (67th), Under pressure (YPA) (67th)  
&nbsp;&nbsp;✗ Struggles: Pressure-to-sack rate (lower=better) (3rd), Play-action grade (6th), Time to throw (17th), Play-action (YPA) (17th), Deep ball accuracy % (24th)  

**Justin Herbert** (LAC) — PassGrade 90.2→73.0 ▼  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (78th), Under pressure (YPA) (75th), Play-action grade (75th)  
&nbsp;&nbsp;✗ Struggles: Deep ball grade (30th), Pressure-to-sack rate (lower=better) (31st)  

**Marcus Mariota** (WAS)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (100th), Big-time throw rate (94th), Play-action (YPA) (92nd), Under pressure (YPA) (89th), Play-action grade (81st)  
&nbsp;&nbsp;✗ Struggles: Deep ball accuracy % (6th), Turnover-worthy play rate (lower=better) (8th), Accuracy % (11th), Under pressure (grade) (31st)  

**Caleb Williams** (CHI) — PassGrade 63.5→72.2 ▲  
&nbsp;&nbsp;✓ Excels: Time to throw (97th), Pressure-to-sack rate (lower=better) (94th), Deep ball grade (88th), Big-time throw rate (83rd), Deep ball accuracy % (82nd)  
&nbsp;&nbsp;✗ Struggles: Accuracy % (0th), Under pressure (YPA) (31st)  

**Patrick Mahomes** (KC) — PassGrade 77.8→70.7 ▼  
&nbsp;&nbsp;✓ Excels: Under pressure (grade) (83rd), Under pressure (YPA) (81st), vs Blitz (YPA) (66th)  
&nbsp;&nbsp;✗ Struggles: Deep ball accuracy % (12th), Deep ball grade (12th), Accuracy % (31st), Play-action grade (31st), Clean pocket (YPA) (32nd)  

**Kyler Murray** (MIN) — PassGrade 77.9→69.5 ▼  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (97th), Accuracy % (92nd), Under pressure (YPA) (78th), Under pressure (grade) (67th)  
&nbsp;&nbsp;✗ Struggles: Big-time throw rate (0th), Avg depth of target (0th), Pressure-to-sack rate (lower=better) (6th), Play-action (YPA) (31st), Play-action grade (33rd)  

**Jacoby Brissett** (ARI) — PassGrade 58.5→69.1 ▲  
&nbsp;&nbsp;✓ Excels: vs Blitz (YPA) (86th), Time to throw (67th)  
&nbsp;&nbsp;✗ Struggles: Big-time throw rate (28th), Under pressure (grade) (28th)  

**Lamar Jackson** (BAL) — PassGrade 93.3→69.0 ▼  
&nbsp;&nbsp;✓ Excels: vs Blitz (YPA) (100th), Play-action (YPA) (100th), Under pressure (YPA) (97th), Avg depth of target (94th), Play-action grade (94th)  
&nbsp;&nbsp;✗ Struggles: Big-time throw rate (11th), Pressure-to-sack rate (lower=better) (19th)  

**Aaron Rodgers** (PIT) — PassGrade 76.1→68.8 ▼  
&nbsp;&nbsp;✓ Excels: Turnover-worthy play rate (lower=better) (75th)  
&nbsp;&nbsp;✗ Struggles: Play-action (YPA) (0th), Avg depth of target (3rd), vs Blitz (YPA) (6th), Time to throw (8th), Clean pocket (YPA) (9th)  

**Daniel Jones** (IND) — PassGrade 67.5→68.7 ▲  
&nbsp;&nbsp;✓ Excels: Under pressure (YPA) (86th), Clean pocket (YPA) (85th), Play-action (YPA) (83rd), Under pressure (grade) (72nd), Pressure-to-sack rate (lower=better) (69th)  
&nbsp;&nbsp;✗ Struggles: Turnover-worthy play rate (lower=better) (17th), Deep ball grade (18th), Big-time throw rate (19th), Play-action grade (22nd), Time to throw (25th)  

**Bryce Young** (CAR) — PassGrade 75.1→68.2 ▼  
&nbsp;&nbsp;✓ Excels: Deep ball accuracy % (100th), Deep ball grade (100th), Under pressure (grade) (89th), Pressure-to-sack rate (lower=better) (78th), Accuracy % (75th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (11th), vs Blitz (YPA) (14th), Clean pocket (YPA) (18th), Under pressure (YPA) (19th), Overall passing grade (31st)  

**Joe Flacco** (CIN) — PassGrade 70.7→66.8 ▼  
&nbsp;&nbsp;✓ Excels: Pressure-to-sack rate (lower=better) (86th), Play-action grade (67th)  
&nbsp;&nbsp;✗ Struggles: Under pressure (YPA) (0th), Under pressure (grade) (8th), Time to throw (11th), vs Blitz (YPA) (11th), Clean pocket (YPA) (12th)  

**Tua Tagovailoa** (ATL) — PassGrade 70.2→65.8 ▼  
&nbsp;&nbsp;✗ Struggles: Time to throw (0th), Turnover-worthy play rate (lower=better) (3rd), Avg depth of target (14th), Under pressure (YPA) (14th), Under pressure (grade) (22nd)  

**Justin Fields** (KC) — PassGrade 65.7→65.5 ▼  
&nbsp;&nbsp;✓ Excels: Time to throw (89th), Turnover-worthy play rate (lower=better) (81st), Accuracy % (69th)  
&nbsp;&nbsp;✗ Struggles: Clean pocket (YPA) (3rd), Big-time throw rate (14th), Play-action grade (14th), Pressure-to-sack rate (lower=better) (17th), Avg depth of target (17th)  

**Baker Mayfield** (TB) — PassGrade 83.6→64.8 ▼  
&nbsp;&nbsp;✗ Struggles: vs Blitz (YPA) (3rd), Turnover-worthy play rate (lower=better) (14th), Under pressure (grade) (17th), Accuracy % (19th), Overall passing grade (19th)  

**Jaxson Dart** (NYG)  
&nbsp;&nbsp;✓ Excels: Time to throw (83rd), Big-time throw rate (81st), Avg depth of target (69th)  
&nbsp;&nbsp;✗ Struggles: Play-action grade (3rd), Play-action (YPA) (6th), Overall passing grade (17th), Clean pocket (YPA) (21st), Pressure-to-sack rate (lower=better) (22nd)  

**C.J. Stroud** (HOU) — PassGrade 77.6→62.0 ▼  
&nbsp;&nbsp;✓ Excels: Pressure-to-sack rate (lower=better) (72nd), Clean pocket (YPA) (68th)  
&nbsp;&nbsp;✗ Struggles: Accuracy % (3rd), Under pressure (grade) (6th), Play-action grade (8th), Overall passing grade (14th), Turnover-worthy play rate (lower=better) (19th)  

**J.J. McCarthy** (MIN)  
&nbsp;&nbsp;✓ Excels: Big-time throw rate (97th), Avg depth of target (89th), Time to throw (75th)  
&nbsp;&nbsp;✗ Struggles: Turnover-worthy play rate (lower=better) (6th), Play-action (YPA) (8th), Overall passing grade (11th), Accuracy % (14th), Pressure-to-sack rate (lower=better) (14th)  

**Geno Smith** (NYJ) — PassGrade 82.4→58.2 ▼  
&nbsp;&nbsp;✓ Excels: Accuracy % (81st)  
&nbsp;&nbsp;✗ Struggles: Pressure-to-sack rate (lower=better) (0th), Under pressure (grade) (0th), Deep ball grade (3rd), Avg depth of target (6th), Overall passing grade (8th)  

**Michael Penix Jr.** (ATL)  
&nbsp;&nbsp;✓ Excels: Pressure-to-sack rate (lower=better) (83rd), Play-action (YPA) (81st), Clean pocket (YPA) (74th), Avg depth of target (72nd)  
&nbsp;&nbsp;✗ Struggles: Deep ball accuracy % (0th), Deep ball grade (0th), Overall passing grade (6th), Big-time throw rate (8th), Accuracy % (17th)  

**Cam Ward** (TEN)  
&nbsp;&nbsp;✓ Excels: Time to throw (69th)  
&nbsp;&nbsp;✗ Struggles: Clean pocket (YPA) (0th), Overall passing grade (3rd), Under pressure (grade) (3rd), Play-action (YPA) (3rd), Accuracy % (8th)  

**Shedeur Sanders** (CLE)  
&nbsp;&nbsp;✓ Excels: Time to throw (100th), vs Blitz (YPA) (80th), Deep ball accuracy % (67th)  
&nbsp;&nbsp;✗ Struggles: Turnover-worthy play rate (lower=better) (0th), Overall passing grade (0th), Play-action grade (0th), Accuracy % (6th), Under pressure (grade) (11th)  


## Running Backs (67)

**Tank Bigsby** (PHI) — Elusive 106.8→123.6 ▲  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (100th), Gap/Power scheme (yds/carry) (98th), Yards after contact / attempt (96th), Rushing grade (96th), Missed tackles forced /carry (94th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (6th), Receiving YPRR (as RB) (20th)  

**Bijan Robinson** (ATL) — Elusive 72.1→120.8 ▲  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (100th), Elusiveness (PFF elusive rating) (98th), Missed tackles forced /carry (98th), Yards after contact / attempt (97th), Explosive run rate (96th)  

**De'Von Achane** (MIA) — Elusive 49.6→96.9 ▲  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (98th), Yards after contact / attempt (98th), Rushing grade (98th), Elusiveness (PFF elusive rating) (97th), Explosive run rate (97th)  

**Tyjae Spears** (TEN) — Elusive 81.0→94.4 ▲  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (96th), Receiving YPRR (as RB) (75th), Breakaway run rate (67th)  
&nbsp;&nbsp;✗ Struggles: Gap/Power scheme (yds/carry) (9th), Explosive run rate (12th), Rushing grade (26th), Yards after contact / attempt (30th)  

**Jaylen Warren** (PIT) — Elusive 76.0→92.5 ▲  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (94th), Outside zone (yds/carry) (92nd), Receiving YPRR (as RB) (91st), Missed tackles forced /carry (86th), Explosive run rate (76th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (10th)  

**Emari Demercado** (KC)  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (100th), Yards after contact / attempt (100th), Elusiveness (PFF elusive rating) (92nd)  
&nbsp;&nbsp;✗ Struggles: Rushing grade (2nd), Explosive run rate (27th)  

**Rhamondre Stevenson** (NE) — Elusive 60.5→83.7 ▲  
&nbsp;&nbsp;✓ Excels: Gap/Power scheme (yds/carry) (96th), Missed tackles forced /carry (93rd), Elusiveness (PFF elusive rating) (91st), Yards after contact / attempt (86th), Receiving YPRR (as RB) (85th)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (26th)  

**Kenneth Walker III** (KC) — Elusive 110.4→83.5 ▼  
&nbsp;&nbsp;✓ Excels: Rushing grade (100th), Missed tackles forced /carry (100th), Explosive run rate (98th), Inside zone (yds/carry) (96th), Receiving YPRR (as RB) (95th)  
&nbsp;&nbsp;✗ Struggles: Gap/Power scheme (yds/carry) (23rd)  

**Ashton Jeanty** (LV)  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (88th), Explosive run rate (70th), Inside zone (yds/carry) (65th)  
&nbsp;&nbsp;✗ Struggles: Gap/Power scheme (yds/carry) (0th), Breakaway run rate (27th)  

**Jahmyr Gibbs** (DET) — Elusive 77.6→80.1 ▲  
&nbsp;&nbsp;✓ Excels: Gap/Power scheme (yds/carry) (100th), Receiving YPRR (as RB) (96th), Breakaway run rate (94th), Missed tackles forced /carry (91st), Elusiveness (PFF elusive rating) (86th)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (20th)  

**Zach Charbonnet** (SEA) — Elusive 81.3→79.6 ▼  
&nbsp;&nbsp;✓ Excels: Rushing grade (97th), Missed tackles forced /carry (87th), Elusiveness (PFF elusive rating) (85th), Yards after contact / attempt (77th), Breakaway run rate (76th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (17th), Receiving YPRR (as RB) (25th), Gap/Power scheme (yds/carry) (32nd)  

**Audric Estime** (NO) — Elusive 49.4→79.2 ▲  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (83rd), Yards after contact / attempt (73rd), Rushing grade (71st)  
&nbsp;&nbsp;✗ Struggles: Explosive run rate (2nd), Breakaway run rate (17th), Inside zone (yds/carry) (25th)  

**Samaje Perine** (CIN)  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (82nd), Gap/Power scheme (yds/carry) (77th), Yards after contact / attempt (70th)  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (12th), Receiving YPRR (as RB) (13th), Explosive run rate (24th)  

**Javonte Williams** (DAL) — Elusive 37.3→75.6 ▲  
&nbsp;&nbsp;✓ Excels: Yards after contact / attempt (91st), Gap/Power scheme (yds/carry) (81st), Elusiveness (PFF elusive rating) (80th), Explosive run rate (79th), Rushing grade (77th)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (8th), Missed tackles forced /carry (16th)  

**Chris Rodriguez Jr.** (JAX)  
&nbsp;&nbsp;✓ Excels: Yards after contact / attempt (85th), Elusiveness (PFF elusive rating) (79th), Missed tackles forced /carry (78th), Outside zone (yds/carry) (74th), Gap/Power scheme (yds/carry) (72nd)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (4th)  

**Bhayshul Tuten** (JAX)  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (77th), Yards after contact / attempt (76th)  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (8th), Gap/Power scheme (yds/carry) (10th), Rushing grade (14th), Explosive run rate (20th), Outside zone (yds/carry) (33rd)  

**Omarion Hampton** (LAC)  
&nbsp;&nbsp;✓ Excels: Rushing grade (88th), Gap/Power scheme (yds/carry) (86th), Breakaway run rate (85th), Yards after contact / attempt (79th), Elusiveness (PFF elusive rating) (76th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (0th)  

**Brian Robinson Jr.** (ATL) — Elusive 48.7→72.9 ▲  
&nbsp;&nbsp;✓ Excels: Elusiveness (PFF elusive rating) (74th), Outside zone (yds/carry) (72nd)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (7th), Rushing grade (15th), Gap/Power scheme (yds/carry) (16th), Breakaway run rate (20th), Explosive run rate (35th)  

**Jonathan Taylor** (IND) — Elusive 35.1→72.4 ▲  
&nbsp;&nbsp;✓ Excels: Explosive run rate (92nd), Yards after contact / attempt (89th), Gap/Power scheme (yds/carry) (88th), Rushing grade (83rd), Breakaway run rate (82nd)  

**Cam Skattebo** (NYG)  
&nbsp;&nbsp;✓ Excels: Missed tackles forced /carry (96th), Receiving YPRR (as RB) (92nd), Rushing grade (74th), Elusiveness (PFF elusive rating) (71st)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (23rd), Explosive run rate (33rd), Breakaway run rate (35th)  

**Jaylen Wright** (MIA) — Elusive 73.2→68.9 ▼  
&nbsp;&nbsp;✓ Excels: Yards after contact / attempt (83rd), Elusiveness (PFF elusive rating) (70th), Receiving YPRR (as RB) (65th)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (0th), Explosive run rate (14th), Breakaway run rate (24th)  

**Jordan Mason** (MIN) — Elusive 77.5→65.0 ▼  
&nbsp;&nbsp;✓ Excels: Rushing grade (86th), Inside zone (yds/carry) (85th), Yards after contact / attempt (82nd), Missed tackles forced /carry (82nd), Gap/Power scheme (yds/carry) (79th)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (1st)  

**Jacory Croskey-Merritt** (WAS)  
&nbsp;&nbsp;✓ Excels: Outside zone (yds/carry) (100th), Yards after contact / attempt (88th), Elusiveness (PFF elusive rating) (67th), Explosive run rate (65th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (14th), Receiving YPRR (as RB) (15th)  

**Chase Brown** (CIN) — Elusive 63.2→64.1 ▲  
&nbsp;&nbsp;✓ Excels: Explosive run rate (74th), Outside zone (yds/carry) (70th), Gap/Power scheme (yds/carry) (67th), Missed tackles forced /carry (66th), Elusiveness (PFF elusive rating) (65th)  

**J.K. Dobbins** (DEN) — Elusive 53.3→64.0 ▲  
&nbsp;&nbsp;✓ Excels: Outside zone (yds/carry) (95th), Missed tackles forced /carry (89th), Breakaway run rate (83rd), Inside zone (yds/carry) (75th), Rushing grade (73rd)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (3rd)  

**Rachaad White** (WAS) — Elusive 60.0→63.6 ▲  
&nbsp;&nbsp;✓ Excels: Rushing grade (94th)  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (15th), Receiving YPRR (as RB) (28th)  

**Travis Etienne Jr.** (NO) — Elusive 32.8→59.4 ▲  
&nbsp;&nbsp;✓ Excels: Explosive run rate (86th), Breakaway run rate (71st), Receiving YPRR (as RB) (69th)  
&nbsp;&nbsp;✗ Struggles: Gap/Power scheme (yds/carry) (19th), Missed tackles forced /carry (27th)  

**RJ Harvey** (DEN)  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (87th), Missed tackles forced /carry (69th)  
&nbsp;&nbsp;✗ Struggles: Explosive run rate (21st), Rushing grade (24th), Gap/Power scheme (yds/carry) (25th), Yards after contact / attempt (26th), Outside zone (yds/carry) (28th)  

**Josh Jacobs** (GB) — Elusive 96.5→57.9 ▼  
&nbsp;&nbsp;✓ Excels: Rushing grade (80th), Inside zone (yds/carry) (79th), Receiving YPRR (as RB) (72nd), Explosive run rate (71st)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (12th)  

**David Montgomery** (HOU) — Elusive 79.9→57.5 ▼  
&nbsp;&nbsp;✓ Excels: Gap/Power scheme (yds/carry) (93rd), Receiving YPRR (as RB) (67th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (33rd)  

**Quinshon Judkins** (CLE)  
&nbsp;&nbsp;✓ Excels: Yards after contact / attempt (67th)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (8th), Rushing grade (17th), Outside zone (yds/carry) (31st)  

**Kenneth Gainwell** (TB) — Elusive 49.1→57.3 ▲  
&nbsp;&nbsp;✓ Excels: Inside zone (yds/carry) (98th), Receiving YPRR (as RB) (88th), Missed tackles forced /carry (80th), Breakaway run rate (73rd), Gap/Power scheme (yds/carry) (68th)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (13th)  

**Isaiah Davis** (NYJ)  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (96th), Yards after contact / attempt (94th), Receiving YPRR (as RB) (71st)  
&nbsp;&nbsp;✗ Struggles: Explosive run rate (15th), Rushing grade (21st)  

**James Cook III** (BUF) — Elusive 53.2→56.4 ▲  
&nbsp;&nbsp;✓ Excels: Explosive run rate (100th), Inside zone (yds/carry) (92nd), Gap/Power scheme (yds/carry) (91st), Outside zone (yds/carry) (90th), Rushing grade (79th)  

**TreVeyon Henderson** (NE)  
&nbsp;&nbsp;✓ Excels: Outside zone (yds/carry) (98th), Breakaway run rate (91st), Gap/Power scheme (yds/carry) (74th), Yards after contact / attempt (71st)  
&nbsp;&nbsp;✗ Struggles: Inside zone (yds/carry) (2nd)  

**Kimani Vidal** (LAC) — Elusive 40.7→53.7 ▲  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (68th)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (10th), Receiving YPRR (as RB) (23rd), Missed tackles forced /carry (24th), Yards after contact / attempt (35th)  

**Derrick Henry** (BAL) — Elusive 87.8→53.6 ▼  
&nbsp;&nbsp;✓ Excels: Explosive run rate (94th), Yards after contact / attempt (92nd), Gap/Power scheme (yds/carry) (90th), Breakaway run rate (89th), Outside zone (yds/carry) (85th)  
&nbsp;&nbsp;✗ Struggles: Missed tackles forced /carry (33rd)  

**Tyler Allgeier** (ARI) — Elusive 105.8→52.1 ▼  
&nbsp;&nbsp;✗ Struggles: Gap/Power scheme (yds/carry) (4th), Breakaway run rate (21st), Missed tackles forced /carry (31st)  

**Nick Chubb** (FA) — Elusive 52.5→51.7 ▼  
&nbsp;&nbsp;✓ Excels: Inside zone (yds/carry) (83rd)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (2nd), Receiving YPRR (as RB) (12th), Yards after contact / attempt (20th), Missed tackles forced /carry (22nd), Explosive run rate (23rd)  

**Bucky Irving** (TB) — Elusive 106.6→51.6 ▼  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (89th), Outside zone (yds/carry) (80th)  
&nbsp;&nbsp;✗ Struggles: Gap/Power scheme (yds/carry) (2nd), Inside zone (yds/carry) (4th), Yards after contact / attempt (4th), Missed tackles forced /carry (9th), Breakaway run rate (11th)  

**Kyle Monangai** (CHI)  
&nbsp;&nbsp;✓ Excels: Gap/Power scheme (yds/carry) (75th), Outside zone (yds/carry) (66th)  
&nbsp;&nbsp;✗ Struggles: Missed tackles forced /carry (11th), Inside zone (yds/carry) (21st), Yards after contact / attempt (33rd)  

**Saquon Barkley** (PHI) — Elusive 64.0→51.4 ▼  
&nbsp;&nbsp;✓ Excels: Explosive run rate (88th), Breakaway run rate (77th)  
&nbsp;&nbsp;✗ Struggles: Yards after contact / attempt (18th), Inside zone (yds/carry) (31st), Missed tackles forced /carry (34th), Receiving YPRR (as RB) (35th)  

**Tony Pollard** (TEN) — Elusive 47.4→51.3 ▲  
&nbsp;&nbsp;✓ Excels: Inside zone (yds/carry) (94th), Outside zone (yds/carry) (84th), Explosive run rate (83rd), Yards after contact / attempt (68th)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (24th), Gap/Power scheme (yds/carry) (28th), Rushing grade (32nd)  

**Emanuel Wilson** (SEA) — Elusive 76.1→50.0 ▼  
&nbsp;&nbsp;✓ Excels: Outside zone (yds/carry) (77th)  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (3rd), Missed tackles forced /carry (4th), Gap/Power scheme (yds/carry) (18th), Receiving YPRR (as RB) (27th), Elusiveness (PFF elusive rating) (35th)  

**Dylan Sampson** (CLE)  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (99th)  
&nbsp;&nbsp;✗ Struggles: Explosive run rate (4th), Rushing grade (8th), Yards after contact / attempt (12th), Elusiveness (PFF elusive rating) (33rd)  

**D'Andre Swift** (CHI) — Elusive 36.7→49.7 ▲  
&nbsp;&nbsp;✓ Excels: Inside zone (yds/carry) (100th), Rushing grade (91st), Explosive run rate (91st), Outside zone (yds/carry) (79th), Missed tackles forced /carry (71st)  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (32nd)  

**Keaton Mitchell** (LAC)  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (97th), Yards after contact / attempt (80th), Receiving YPRR (as RB) (80th)  
&nbsp;&nbsp;✗ Struggles: Rushing grade (4th), Outside zone (yds/carry) (15th), Elusiveness (PFF elusive rating) (30th)  

**Breece Hall** (NYJ) — Elusive 59.5→48.6 ▼  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (88th), Rushing grade (85th), Receiving YPRR (as RB) (84th), Missed tackles forced /carry (84th), Explosive run rate (80th)  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (29th)  

**Ray Davis** (BUF) — Elusive 70.9→48.5 ▼  
&nbsp;&nbsp;✓ Excels: Outside zone (yds/carry) (97th), Receiving YPRR (as RB) (76th)  
&nbsp;&nbsp;✗ Struggles: Explosive run rate (26th), Elusiveness (PFF elusive rating) (27th), Rushing grade (27th), Yards after contact / attempt (32nd)  

**Devin Neal** (NO)  
&nbsp;&nbsp;✗ Struggles: Rushing grade (3rd), Yards after contact / attempt (6th), Explosive run rate (6th), Inside zone (yds/carry) (15th), Elusiveness (PFF elusive rating) (26th)  

**Kyren Williams** (LAR) — Elusive 46.0→48.4 ▲  
&nbsp;&nbsp;✓ Excels: Rushing grade (92nd), Explosive run rate (89th), Outside zone (yds/carry) (88th), Inside zone (yds/carry) (73rd)  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (23rd), Elusiveness (PFF elusive rating) (24th)  

**Rico Dowdle** (PIT) — Elusive 63.5→46.6 ▼  
&nbsp;&nbsp;✓ Excels: Explosive run rate (73rd), Receiving YPRR (as RB) (68th)  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (23rd), Gap/Power scheme (yds/carry) (30th), Rushing grade (33rd)  

**Ty Johnson** (BUF) — Elusive 49.6→46.2 ▼  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (73rd)  
&nbsp;&nbsp;✗ Struggles: Explosive run rate (0th), Yards after contact / attempt (3rd), Outside zone (yds/carry) (16th), Elusiveness (PFF elusive rating) (21st), Rushing grade (29th)  

**Kareem Hunt** (FA) — Elusive 40.1→45.7 ▲  
&nbsp;&nbsp;✓ Excels: Rushing grade (67th)  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (6th), Gap/Power scheme (yds/carry) (14th), Missed tackles forced /carry (14th), Receiving YPRR (as RB) (17th), Elusiveness (PFF elusive rating) (20th)  

**Christian McCaffrey** (SF) — Elusive 33.2→45.2 ▲  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (97th), Explosive run rate (85th)  
&nbsp;&nbsp;✗ Struggles: Rushing grade (11th), Elusiveness (PFF elusive rating) (18th), Breakaway run rate (18th), Yards after contact / attempt (27th), Outside zone (yds/carry) (30th)  

**Tyrone Tracy Jr.** (NYG) — Elusive 55.6→43.9 ▼  
&nbsp;&nbsp;✓ Excels: Inside zone (yds/carry) (88th)  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (17th), Missed tackles forced /carry (20th), Yards after contact / attempt (21st), Outside zone (yds/carry) (23rd)  

**Blake Corum** (LAR) — Elusive 40.6→43.2 ▲  
&nbsp;&nbsp;✓ Excels: Outside zone (yds/carry) (93rd), Rushing grade (89th), Gap/Power scheme (yds/carry) (82nd), Explosive run rate (77th), Missed tackles forced /carry (76th)  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (15th), Yards after contact / attempt (15th), Receiving YPRR (as RB) (16th), Inside zone (yds/carry) (27th)  

**Devin Singletary** (NYG) — Elusive 60.7→42.4 ▼  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (77th)  
&nbsp;&nbsp;✗ Struggles: Outside zone (yds/carry) (5th), Missed tackles forced /carry (6th), Yards after contact / attempt (8th), Breakaway run rate (9th), Explosive run rate (11th)  

**Brashard Smith** (KC)  
&nbsp;&nbsp;✓ Excels: Receiving YPRR (as RB) (93rd)  
&nbsp;&nbsp;✗ Struggles: Rushing grade (0th), Breakaway run rate (2nd), Yards after contact / attempt (2nd), Explosive run rate (3rd), Outside zone (yds/carry) (7th)  

**Ollie Gordon II** (MIA)  
&nbsp;&nbsp;✗ Struggles: Yards after contact / attempt (0th), Receiving YPRR (as RB) (5th), Gap/Power scheme (yds/carry) (5th), Explosive run rate (9th), Elusiveness (PFF elusive rating) (11th)  

**Malik Davis** (DAL)  
&nbsp;&nbsp;✓ Excels: Breakaway run rate (92nd), Inside zone (yds/carry) (90th), Yards after contact / attempt (74th)  
&nbsp;&nbsp;✗ Struggles: Receiving YPRR (as RB) (0th), Explosive run rate (8th), Elusiveness (PFF elusive rating) (9th), Rushing grade (9th)  

**Alvin Kamara** (NO) — Elusive 45.7→36.0 ▼  
&nbsp;&nbsp;✗ Struggles: Rushing grade (6th), Elusiveness (PFF elusive rating) (8th), Inside zone (yds/carry) (12th), Gap/Power scheme (yds/carry) (12th), Breakaway run rate (14th)  

**Woody Marks** (HOU)  
&nbsp;&nbsp;✗ Struggles: Missed tackles forced /carry (0th), Elusiveness (PFF elusive rating) (6th), Outside zone (yds/carry) (8th), Yards after contact / attempt (14th), Rushing grade (18th)  

**Isiah Pacheco** (DET) — Elusive 26.6→30.1 ▲  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (4th), Breakaway run rate (4th), Receiving YPRR (as RB) (11th), Rushing grade (12th), Missed tackles forced /carry (18th)  

**Chuba Hubbard** (CAR) — Elusive 63.8→30.1 ▼  
&nbsp;&nbsp;✗ Struggles: Breakaway run rate (0th), Missed tackles forced /carry (2nd), Elusiveness (PFF elusive rating) (3rd), Yards after contact / attempt (11th), Outside zone (yds/carry) (18th)  

**Sean Tucker** (TB) — Elusive 49.7→28.6 ▼  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (2nd), Outside zone (yds/carry) (3rd), Yards after contact / attempt (9th), Explosive run rate (17th), Receiving YPRR (as RB) (19th)  

**Aaron Jones Sr.** (MIN) — Elusive 48.0→25.0 ▼  
&nbsp;&nbsp;✗ Struggles: Elusiveness (PFF elusive rating) (0th), Missed tackles forced /carry (7th), Outside zone (yds/carry) (21st), Rushing grade (23rd), Yards after contact / attempt (24th)  


## Wide Receivers (119)

**Kayshon Boutte** (NE) — YPRR 1.26→1.45 ▲  
&nbsp;&nbsp;✓ Excels: Overall efficiency (DVOA) (100th), Avg depth of target (aDOT) (96th), QB rating when targeted (96th), Deep ball (yds/deep target) (93rd), Drop rate (lower=better) (90th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (3rd), Red zone targets (volume) (14th), From slot (yds/route) (14th), vs Man (yds/man route, FTN) (28th), Separation (step sep at catch pt) (32nd)  

**Jaxon Smith-Njigba** (SEA) — YPRR 1.81→3.42 ▲  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (100th), Deep routes (yds/route) (100th), vs Zone coverage (YPRR) (99th), Overall YPRR (99th), vs Man (QB rating when targeted) (99th)  

**Christian Watson** (GB) — YPRR 2.26→2.28 –  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (99th), Overall efficiency (DVOA) (99th), Deep routes (yds/route) (97th), vs Zone coverage (YPRR) (97th), vs Zone (yds/zone route, FTN) (96th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (32nd)  

**Tyreek Hill** (FA) — YPRR 1.75→2.55 ▲  
&nbsp;&nbsp;✓ Excels: Overall YPRR (98th), vs Zone coverage (YPRR) (90th), Short routes (yds/route) (86th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (24th)  

**Puka Nacua** (LAR) — YPRR 3.23→3.57 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (100th), Overall YPRR (100th), From slot (yds/route) (100th), vs Zone (yds/zone route, FTN) (100th), Success rate (100th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (29th)  

**Alec Pierce** (IND) — YPRR 1.82→2.1 ▲  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (99th), Overall efficiency (DVOA) (97th), Red zone TD rate (TD/target) (94th), Drop rate (lower=better) (92nd), Deep routes (yds/route) (91st)  

**Jalen Coker** (CAR) — YPRR 1.72→1.61 ▼  
&nbsp;&nbsp;✓ Excels: Contested catch rate (98th), vs Man (QB rating when targeted) (97th), Overall efficiency (DVOA) (96th), vs Man coverage (YPRR) (95th), Drop rate (lower=better) (89th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (8th), From slot (yds/route) (11th), Short routes (yds/route) (22nd), vs Zone (yds/zone route, FTN) (30th), Avg depth of target (aDOT) (32nd)  

**Tyquan Thornton** (KC)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (100th), Drop rate (lower=better) (98th), QB rating when targeted (95th), Deep routes (yds/route) (95th), Overall efficiency (DVOA) (95th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (9th), Short routes (yds/route) (11th), Success rate (12th), Contested catch rate (28th)  

**Jameson Williams** (DET) — YPRR 1.97→1.86 ▼  
&nbsp;&nbsp;✓ Excels: QB rating when targeted (98th), vs Man (QB rating when targeted) (94th), Separation (step sep at catch pt) (94th), Overall efficiency (DVOA) (94th), Yards after catch / reception (93rd)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (13th), Drop rate (lower=better) (15th)  

**Stefon Diggs** (FA) — YPRR 1.84→2.08 ▲  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (97th), vs Zone (yds/zone route, FTN) (95th), Contested catch rate (94th), Deep ball (yds/deep target) (94th), Success rate (94th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (15th)  

**George Pickens** (DAL) — YPRR 2.11→2.35 ▲  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (99th), vs Man coverage (YPRR) (98th), Red zone targets (volume) (98th), Success rate (97th), vs Man (QB rating when targeted) (96th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (33rd)  

**Terry McLaurin** (WAS) — YPRR 1.97→2.22 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (99th), vs Zone coverage (YPRR) (95th), Deep routes (yds/route) (93rd), Out wide (yds/route) (93rd), Overall efficiency (DVOA) (91st)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (12th), Yards after catch / reception (13th), vs Man coverage (YPRR) (14th), vs Man (QB rating when targeted) (18th), From slot (yds/route) (19th)  

**Kendrick Bourne** (ARI) — YPRR 1.06→1.4 ▲  
&nbsp;&nbsp;✓ Excels: Overall efficiency (DVOA) (90th), vs Zone (yds/zone route, FTN) (70th), vs Zone coverage (YPRR) (65th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (2nd), Red zone targets (volume) (5th), vs Man coverage (YPRR) (10th), vs Man (yds/man route, FTN) (13th)  

**Ricky Pearsall** (SF) — YPRR 1.31→1.68 ▲  
&nbsp;&nbsp;✓ Excels: Contested catch rate (99th), vs Man (yds/man route, FTN) (94th), Deep routes (yds/route) (92nd), Overall efficiency (DVOA) (88th), vs Man coverage (YPRR) (85th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (5th), QB rating when targeted (12th), Red zone targets (volume) (19th)  

**Ryan Flournoy** (DAL)  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (93rd), Red zone TD rate (TD/target) (93rd), From slot (yds/route) (91st), vs Man (yds/man route, FTN) (89th), Drop rate (lower=better) (88th)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (26th), Avg depth of target (aDOT) (28th), Short routes (yds/route) (30th)  

**Kalif Raymond** (CHI) — YPRR 1.64→1.33 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (92nd), Overall efficiency (DVOA) (86th), Short routes (yds/route) (74th), vs Man (yds/man route, FTN) (72nd), vs Man coverage (YPRR) (70th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (4th), Separation (step sep at catch pt) (11th), Success rate (18th), Deep routes (yds/route) (24th), vs Zone (yds/zone route, FTN) (27th)  

**Luther Burden III** (CHI)  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (99th), vs Zone (yds/zone route, FTN) (98th), Short routes (yds/route) (98th), Yards after catch / reception (95th), vs Zone coverage (YPRR) (94th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (9th), Red zone targets (volume) (21st), Drop rate (lower=better) (23rd), Separation (step sep at catch pt) (33rd)  

**KaVontae Turpin** (DAL) — YPRR 2.06→1.65 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (100th), Out wide (yds/route) (87th), Overall efficiency (DVOA) (84th), QB rating when targeted (83rd), vs Zone coverage (YPRR) (77th)  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (12th), Drop rate (lower=better) (12th), Success rate (16th), Short routes (yds/route) (20th), Avg depth of target (aDOT) (21st)  

**Tee Higgins** (CIN) — YPRR 2.05→1.62 ▼  
&nbsp;&nbsp;✓ Excels: QB rating when targeted (90th), vs Man coverage (YPRR) (88th), Deep routes (yds/route) (87th), Overall efficiency (DVOA) (83rd), vs Man (QB rating when targeted) (83rd)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (18th), Short routes (yds/route) (23rd), vs Zone coverage (YPRR) (32nd)  

**Devaughn Vele** (NO) — YPRR 1.43→1.21 ▼  
&nbsp;&nbsp;✓ Excels: Contested catch rate (100th), Short routes (yds/route) (99th), Drop rate (lower=better) (97th), QB rating when targeted (84th), Overall efficiency (DVOA) (82nd)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (1st), vs Man coverage (YPRR) (8th), Red zone targets (volume) (15th), Success rate (23rd), vs Man (yds/man route, FTN) (23rd)  

**Luke McCaffrey** (WAS) — YPRR 0.63→1.92 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (94th), Out wide (yds/route) (94th), vs Zone coverage (YPRR) (83rd), Overall YPRR (82nd)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (4th), vs Man (yds/man route, FTN) (30th)  

**Nico Collins** (HOU) — YPRR 2.86→2.27 ▼  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (96th), Separation (step sep at catch pt) (96th), Deep routes (yds/route) (96th), Drop rate (lower=better) (95th), Short routes (yds/route) (95th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (29th)  

**Zay Flowers** (BAL) — YPRR 2.25→2.53 ▲  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (98th), vs Man (yds/man route, FTN) (98th), Overall YPRR (97th), vs Zone coverage (YPRR) (96th), Deep ball (yds/deep target) (96th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (9th), Avg depth of target (aDOT) (33rd)  

**Jaylen Waddle** (DEN) — YPRR 1.53→2.19 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (92nd), Out wide (yds/route) (90th), Short routes (yds/route) (90th), vs Zone (yds/zone route, FTN) (90th), Overall YPRR (88th)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (30th), QB rating when targeted (34th)  

**Jaylin Noel** (HOU)  
&nbsp;&nbsp;✓ Excels: Deep ball (yds/deep target) (100th), Deep routes (yds/route) (99th), Overall efficiency (DVOA) (78th), QB rating when targeted (74th), vs Zone (yds/zone route, FTN) (71st)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (6th), Success rate (10th), vs Man coverage (YPRR) (12th), Red zone targets (volume) (26th), Short routes (yds/route) (29th)  

**Romeo Doubs** (NE) — YPRR 1.62→1.86 ▲  
&nbsp;&nbsp;✓ Excels: Short routes (yds/route) (97th), Red zone targets (volume) (88th), QB rating when targeted (87th), vs Zone coverage (YPRR) (80th), Overall efficiency (DVOA) (77th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (31st)  

**Mack Hollins** (NE) — YPRR 1.05→1.72 ▲  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (99th), Contested catch rate (86th), Avg depth of target (aDOT) (83rd), vs Zone (yds/zone route, FTN) (77th), Out wide (yds/route) (77th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (8th), Separation (step sep at catch pt) (9th), Yards after catch / reception (10th), From slot (yds/route) (15th), vs Man coverage (YPRR) (21st)  

**DeMario Douglas** (NE) — YPRR 1.4→1.82 ▲  
&nbsp;&nbsp;✓ Excels: vs Man (QB rating when targeted) (100th), Out wide (yds/route) (100th), vs Man (yds/man route, FTN) (99th), Deep ball (yds/deep target) (97th), QB rating when targeted (97th)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (8th), Avg depth of target (aDOT) (25th), Success rate (30th)  

**Parker Washington** (JAX) — YPRR 1.02→2.19 ▲  
&nbsp;&nbsp;✓ Excels: Contested catch rate (92nd), vs Man (yds/man route, FTN) (91st), vs Man coverage (YPRR) (90th), From slot (yds/route) (90th), Overall YPRR (89th)  
&nbsp;&nbsp;✗ Struggles: Deep routes (yds/route) (9th), Drop rate (lower=better) (33rd)  

**Tre' Harris** (LAC)  
&nbsp;&nbsp;✓ Excels: Contested catch rate (97th), Drop rate (lower=better) (78th), Overall efficiency (DVOA) (73rd), Yards after catch / reception (71st), Separation (step sep at catch pt) (68th)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (16th), From slot (yds/route) (18th), Overall YPRR (22nd), Deep routes (yds/route) (22nd), Red zone targets (volume) (23rd)  

**Dontayvion Wicks** (PHI) — YPRR 1.41→1.39 –  
&nbsp;&nbsp;✓ Excels: Contested catch rate (87th), Overall efficiency (DVOA) (72nd), vs Man (yds/man route, FTN) (69th), vs Man coverage (YPRR) (66th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (8th), Red zone targets (volume) (20th), Short routes (yds/route) (26th), Drop rate (lower=better) (29th), vs Zone (yds/zone route, FTN) (31st)  

**Marvin Harrison Jr.** (ARI) — YPRR 1.63→1.58 –  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (90th), vs Man coverage (YPRR) (83rd), Avg depth of target (aDOT) (79th), Overall efficiency (DVOA) (71st), Deep routes (yds/route) (70th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (21st), Yards after catch / reception (22nd)  

**Amon-Ra St. Brown** (DET) — YPRR 2.35→2.48 ▲  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (100th), Red zone targets (volume) (100th), Success rate (98th), Overall YPRR (96th), Short routes (yds/route) (96th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (13th), Contested catch rate (32nd), Deep ball (yds/deep target) (33rd)  

**CeeDee Lamb** (DAL) — YPRR 2.27→2.37 ▲  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (100th), vs Man coverage (YPRR) (99th), Deep ball (yds/deep target) (99th), Overall YPRR (96th), Deep routes (yds/route) (94th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (16th), Drop rate (lower=better) (26th), vs Man (QB rating when targeted) (31st)  

**Drake London** (ATL) — YPRR 2.32→2.34 –  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (97th), From slot (yds/route) (96th), Red zone TD rate (TD/target) (96th), Overall YPRR (93rd), vs Zone (yds/zone route, FTN) (91st)  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (30th)  

**Tez Johnson** (TB)  
&nbsp;&nbsp;✓ Excels: QB rating when targeted (100th), Red zone TD rate (TD/target) (91st), Drop rate (lower=better) (72nd), Overall efficiency (DVOA) (67th)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (3rd), vs Man coverage (YPRR) (5th), Deep ball (yds/deep target) (9th), Separation (step sep at catch pt) (14th), Success rate (21st)  

**Jayden Reed** (GB) — YPRR 2.2→1.67 ▼  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (97th), From slot (yds/route) (92nd), Overall YPRR (66th)  
&nbsp;&nbsp;✗ Struggles: Out wide (yds/route) (1st), Separation (step sep at catch pt) (3rd), vs Man coverage (YPRR) (28th), vs Zone (yds/zone route, FTN) (34th)  

**Michael Pittman Jr.** (PIT) — YPRR 1.68→1.46 ▼  
&nbsp;&nbsp;✓ Excels: vs Man (QB rating when targeted) (87th), Success rate (85th), Red zone targets (volume) (81st), Separation (step sep at catch pt) (80th), Red zone TD rate (TD/target) (77th)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (10th), Avg depth of target (aDOT) (16th), Deep routes (yds/route) (20th), vs Man coverage (YPRR) (22nd), vs Man (yds/man route, FTN) (27th)  

**Jack Bech** (LV)  
&nbsp;&nbsp;✓ Excels: Contested catch rate (77th), vs Man (yds/man route, FTN) (68th)  
&nbsp;&nbsp;✗ Struggles: Deep routes (yds/route) (1st), Success rate (4th), vs Zone (yds/zone route, FTN) (11th), Red zone targets (volume) (12th), Separation (step sep at catch pt) (16th)  

**Michael Wilson** (ARI) — YPRR 1.09→1.59 ▲  
&nbsp;&nbsp;✓ Excels: Contested catch rate (90th), Success rate (88th), Red zone targets (volume) (86th), vs Man (yds/man route, FTN) (80th), vs Man coverage (YPRR) (80th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (11th), From slot (yds/route) (24th), Short routes (yds/route) (35th)  

**Tetairoa McMillan** (CAR)  
&nbsp;&nbsp;✓ Excels: Short routes (yds/route) (88th), Success rate (84th), Red zone targets (volume) (83rd), vs Man (yds/man route, FTN) (83rd), From slot (yds/route) (83rd)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (13th), vs Man (QB rating when targeted) (17th), Drop rate (lower=better) (34th), QB rating when targeted (35th)  

**Mike Evans** (SF) — YPRR 2.52→1.62 ▼  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (85th), Short routes (yds/route) (76th), vs Man (QB rating when targeted) (75th), Deep routes (yds/route) (74th), vs Zone coverage (YPRR) (66th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (0th), Drop rate (lower=better) (16th), QB rating when targeted (18th)  

**Jauan Jennings** (MIN) — YPRR 2.26→1.35 ▼  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (96th), Red zone TD rate (TD/target) (87th), Separation (step sep at catch pt) (78th), Contested catch rate (71st), Success rate (68th)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (29th), QB rating when targeted (32nd)  

**Keenan Allen** (FA) — YPRR 1.36→1.62 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (68th)  
&nbsp;&nbsp;✗ Struggles: Deep routes (yds/route) (3rd), Avg depth of target (aDOT) (14th), Yards after catch / reception (21st), vs Man (QB rating when targeted) (28th)  

**DeAndre Hopkins** (FA) — YPRR 1.61→1.63 –  
&nbsp;&nbsp;✓ Excels: Contested catch rate (91st), Avg depth of target (aDOT) (88th), vs Man coverage (YPRR) (87th), Out wide (yds/route) (79th), vs Man (yds/man route, FTN) (75th)  
&nbsp;&nbsp;✗ Struggles: From slot (yds/route) (6th), Red zone targets (volume) (7th), Separation (step sep at catch pt) (13th), Success rate (15th), vs Zone coverage (YPRR) (26th)  

**Cooper Kupp** (SEA) — YPRR 1.88→1.49 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (84th)  
&nbsp;&nbsp;✗ Struggles: Deep routes (yds/route) (13th), Avg depth of target (aDOT) (18th), vs Man (QB rating when targeted) (25th), Red zone TD rate (TD/target) (27th), From slot (yds/route) (33rd)  

**DeVonta Smith** (PHI) — YPRR 2.03→1.92 ▼  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (96th), vs Zone (yds/zone route, FTN) (88th), Deep ball (yds/deep target) (84th), Success rate (83rd), vs Zone coverage (YPRR) (81st)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (25th), vs Man (QB rating when targeted) (32nd), Red zone TD rate (TD/target) (34th)  

**Courtland Sutton** (DEN) — YPRR 1.88→1.53 ▼  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (95th), Separation (step sep at catch pt) (92nd), Success rate (92nd), vs Man (yds/man route, FTN) (86th), vs Man coverage (YPRR) (76th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (14th), Drop rate (lower=better) (31st)  

**Jayden Higgins** (HOU)  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (99th), Drop rate (lower=better) (94th), Short routes (yds/route) (75th), Separation (step sep at catch pt) (69th), QB rating when targeted (65th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (13th), Yards after catch / reception (16th), From slot (yds/route) (21st), vs Man (yds/man route, FTN) (26th), vs Man coverage (YPRR) (30th)  

**A.J. Brown** (NE) — YPRR 2.61→1.96 ▼  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (95th), vs Man coverage (YPRR) (94th), From slot (yds/route) (93rd), Success rate (88th), Short routes (yds/route) (87th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (30th)  

**Davante Adams** (LAR) — YPRR 2.04→1.9 ▼  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (99th), Separation (step sep at catch pt) (95th), Red zone TD rate (TD/target) (89th), Success rate (81st), Avg depth of target (aDOT) (80th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (6th), Contested catch rate (9th), Drop rate (lower=better) (18th), Deep routes (yds/route) (26th), Deep ball (yds/deep target) (29th)  

**DK Metcalf** (PIT) — YPRR 1.81→1.78 –  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (98th), vs Zone coverage (YPRR) (86th), Deep routes (yds/route) (86th), vs Man (QB rating when targeted) (80th), vs Zone (yds/zone route, FTN) (78th)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (14th), Drop rate (lower=better) (30th)  

**Ja'Marr Chase** (CIN) — YPRR 2.41→2.23 ▼  
&nbsp;&nbsp;✓ Excels: Success rate (99th), Separation (step sep at catch pt) (98th), Red zone targets (volume) (97th), vs Zone (yds/zone route, FTN) (92nd), vs Zone coverage (YPRR) (91st)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (19th), vs Man (QB rating when targeted) (27th), Deep ball (yds/deep target) (32nd), vs Man coverage (YPRR) (33rd)  

**Pat Bryant** (DEN)  
&nbsp;&nbsp;✓ Excels: Contested catch rate (84th), Short routes (yds/route) (81st), Yards after catch / reception (70th), Separation (step sep at catch pt) (66th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (4th), Deep routes (yds/route) (15th), vs Man (yds/man route, FTN) (20th), QB rating when targeted (23rd), vs Man coverage (YPRR) (23rd)  

**Josh Downs** (IND) — YPRR 2.2→1.49 ▼  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (82nd), From slot (yds/route) (68th), Success rate (66th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (9th), Out wide (yds/route) (12th), Short routes (yds/route) (13th), Avg depth of target (aDOT) (17th), Contested catch rate (17th)  

**Quentin Johnston** (LAC) — YPRR 1.63→1.44 ▼  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (97th), vs Man (QB rating when targeted) (93rd), Deep ball (yds/deep target) (90th), QB rating when targeted (88th), Red zone targets (volume) (77th)  

**Xavier Hutchinson** (HOU) — YPRR 0.66→1.05 ▲  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (94th), Red zone TD rate (TD/target) (67th)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (6th), QB rating when targeted (9th), Out wide (yds/route) (9th), Overall YPRR (18th), Short routes (yds/route) (19th)  

**Jalen Nailor** (LV) — YPRR 1.05→1.06 –  
&nbsp;&nbsp;✓ Excels: Contested catch rate (95th), Red zone TD rate (TD/target) (84th), Deep ball (yds/deep target) (83rd), Drop rate (lower=better) (74th), vs Man coverage (YPRR) (73rd)  
&nbsp;&nbsp;✗ Struggles: Short routes (yds/route) (0th), vs Zone (yds/zone route, FTN) (6th), vs Zone coverage (YPRR) (8th), Out wide (yds/route) (16th), Overall YPRR (19th)  

**Jakobi Meyers** (JAX) — YPRR 1.76→1.52 ▼  
&nbsp;&nbsp;✓ Excels: Success rate (91st), Red zone targets (volume) (84th), Separation (step sep at catch pt) (81st), Short routes (yds/route) (80th), Deep ball (yds/deep target) (75th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (7th), Deep routes (yds/route) (14th), QB rating when targeted (20th), Avg depth of target (aDOT) (22nd)  

**Deebo Samuel Sr.** (FA) — YPRR 1.6→1.66 –  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (95th), vs Man (QB rating when targeted) (92nd), Yards after catch / reception (91st), Short routes (yds/route) (85th), vs Man (yds/man route, FTN) (84th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (5th), Deep routes (yds/route) (29th)  

**Ladd McConkey** (LAC) — YPRR 2.59→1.35 ▼  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (88th), Red zone targets (volume) (78th), Success rate (74th), Yards after catch / reception (68th), Drop rate (lower=better) (66th)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (1st), Contested catch rate (3rd), Deep routes (yds/route) (30th), vs Zone coverage (YPRR) (33rd), Avg depth of target (aDOT) (34th)  

**Calvin Ridley** (TEN) — YPRR 1.86→1.89 –  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (85th), vs Zone (yds/zone route, FTN) (83rd), Overall YPRR (79th), Avg depth of target (aDOT) (76th), Out wide (yds/route) (76th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (2nd), Success rate (6th), Drop rate (lower=better) (7th), QB rating when targeted (10th), Separation (step sep at catch pt) (25th)  

**Chris Godwin Jr.** (TB) — YPRR 2.36→1.36 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (90th), Red zone TD rate (TD/target) (70th)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (6th), Deep routes (yds/route) (7th), Avg depth of target (aDOT) (8th), vs Man (yds/man route, FTN) (22nd), vs Zone coverage (YPRR) (28th)  

**Tre Tucker** (LV) — YPRR 0.84→1.2 ▲  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (78th), Red zone TD rate (TD/target) (74th), QB rating when targeted (67th)  
&nbsp;&nbsp;✗ Struggles: Short routes (yds/route) (6th), From slot (yds/route) (10th), Contested catch rate (24th), Deep routes (yds/route) (28th), vs Zone (yds/zone route, FTN) (28th)  

**Greg Dortch** (DET) — YPRR 1.18→0.96 ▼  
&nbsp;&nbsp;✓ Excels: QB rating when targeted (94th), Yards after catch / reception (94th), Short routes (yds/route) (92nd)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (0th), Separation (step sep at catch pt) (0th), Success rate (0th), Deep routes (yds/route) (2nd), vs Zone coverage (YPRR) (5th)  

**Kevin Coleman Jr.** (MIA)  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (83rd)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (4th), From slot (yds/route) (29th)  

**Rome Odunze** (CHI) — YPRR 1.18→1.53 ▲  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (90th), Separation (step sep at catch pt) (90th), vs Man (QB rating when targeted) (79th), vs Man (yds/man route, FTN) (76th), Out wide (yds/route) (72nd)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (16th), Deep ball (yds/deep target) (23rd), Drop rate (lower=better) (28th), QB rating when targeted (30th), From slot (yds/route) (35th)  

**Chris Olave** (NO) — YPRR 2.13→1.98 ▼  
&nbsp;&nbsp;✓ Excels: Success rate (96th), Deep routes (yds/route) (90th), Separation (step sep at catch pt) (89th), Out wide (yds/route) (86th), Red zone targets (volume) (85th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (20th)  

**Brian Thomas Jr.** (JAX) — YPRR 2.45→1.45 ▼  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (89th), vs Man (yds/man route, FTN) (78th), Deep routes (yds/route) (71st), vs Man (QB rating when targeted) (68th), Success rate (67th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (10th), Deep ball (yds/deep target) (14th), Short routes (yds/route) (16th), Contested catch rate (20th), Red zone TD rate (TD/target) (20th)  

**Rashee Rice** (KC)  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (99th), vs Zone coverage (YPRR) (98th), vs Zone (yds/zone route, FTN) (97th), From slot (yds/route) (95th), Red zone targets (volume) (94th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (2nd), Contested catch rate (5th), Deep routes (yds/route) (8th), vs Man (QB rating when targeted) (10th), vs Man coverage (YPRR) (11th)  

**Keon Coleman** (BUF) — YPRR 1.55→1.26 ▼  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (18th), Yards after catch / reception (19th), vs Man coverage (YPRR) (19th), Drop rate (lower=better) (19th), Overall YPRR (34th)  

**Matthew Golden** (GB)  
&nbsp;&nbsp;✓ Excels: Deep ball (yds/deep target) (86th), Deep routes (yds/route) (85th), Drop rate (lower=better) (80th), From slot (yds/route) (76th), Avg depth of target (aDOT) (75th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (3rd), Short routes (yds/route) (4th), vs Man (yds/man route, FTN) (17th), Success rate (22nd), Separation (step sep at catch pt) (26th)  

**Jordan Addison** (MIN) — YPRR 1.64→1.36 ▼  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (87th), Deep routes (yds/route) (79th), Red zone targets (volume) (73rd)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (8th), From slot (yds/route) (8th), Short routes (yds/route) (9th), vs Man (yds/man route, FTN) (9th), vs Zone coverage (YPRR) (14th)  

**DJ Moore** (BUF) — YPRR 1.44→1.24 ▼  
&nbsp;&nbsp;✓ Excels: Contested catch rate (83rd), vs Man (QB rating when targeted) (82nd), QB rating when targeted (80th)  
&nbsp;&nbsp;✗ Struggles: vs Zone coverage (YPRR) (31st), Overall YPRR (32nd)  

**Darius Slayton** (NYG) — YPRR 1.08→1.24 ▲  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (79th), Short routes (yds/route) (78th), Avg depth of target (aDOT) (77th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (1st), vs Man coverage (YPRR) (4th), Contested catch rate (8th), Drop rate (lower=better) (9th), Deep ball (yds/deep target) (19th)  

**Tutu Atwell** (MIA) — YPRR 2.24→1.22 ▼  
&nbsp;&nbsp;✓ Excels: Deep routes (yds/route) (98th), vs Man coverage (YPRR) (78th), From slot (yds/route) (71st)  
&nbsp;&nbsp;✗ Struggles: Out wide (yds/route) (3rd), vs Zone coverage (YPRR) (9th), Separation (step sep at catch pt) (12th), vs Zone (yds/zone route, FTN) (26th), Overall YPRR (31st)  

**Andrei Iosivas** (CIN) — YPRR 0.84→0.79 –  
&nbsp;&nbsp;✓ Excels: Deep ball (yds/deep target) (65th)  
&nbsp;&nbsp;✗ Struggles: vs Zone (yds/zone route, FTN) (1st), Contested catch rate (1st), Overall YPRR (4th), From slot (yds/route) (9th), vs Zone coverage (YPRR) (10th)  

**Elic Ayomanor** (TEN)  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (97th), Contested catch rate (82nd), From slot (yds/route) (78th), Avg depth of target (aDOT) (65th)  
&nbsp;&nbsp;✗ Struggles: Short routes (yds/route) (7th), Out wide (yds/route) (11th), QB rating when targeted (11th), Deep routes (yds/route) (16th), Overall YPRR (17th)  

**Dyami Brown** (WAS) — YPRR 1.53→1.11 ▼  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (86th), Contested catch rate (66th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (1st), Yards after catch / reception (2nd), Success rate (5th), From slot (yds/route) (7th), Red zone TD rate (TD/target) (10th)  

**Tory Horton** (SEA)  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (88th), vs Man coverage (YPRR) (77th), From slot (yds/route) (73rd)  
&nbsp;&nbsp;✗ Struggles: vs Zone (yds/zone route, FTN) (5th), Separation (step sep at catch pt) (5th), vs Zone coverage (YPRR) (12th), Out wide (yds/route) (17th), Deep routes (yds/route) (27th)  

**Troy Franklin** (DEN) — YPRR 1.14→1.42 ▲  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (91st), Separation (step sep at catch pt) (84th), Success rate (70th), Avg depth of target (aDOT) (69th), vs Zone coverage (YPRR) (69th)  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (9th), vs Man (QB rating when targeted) (14th), Deep ball (yds/deep target) (17th), Drop rate (lower=better) (20th), Overall efficiency (DVOA) (27th)  

**Xavier Worthy** (KC) — YPRR 1.51→1.25 ▼  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (94th), Yards after catch / reception (72nd)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (13th), From slot (yds/route) (16th), Short routes (yds/route) (17th), Deep routes (yds/route) (17th), Red zone TD rate (TD/target) (24th)  

**Garrett Wilson** (NYJ) — YPRR 1.69→1.76 –  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (88th), From slot (yds/route) (85th), vs Man (yds/man route, FTN) (79th), vs Zone (yds/zone route, FTN) (73rd), Overall YPRR (71st)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (16th), Yards after catch / reception (16th), Success rate (24th), Overall efficiency (DVOA) (25th), Avg depth of target (aDOT) (27th)  

**Jordan Whittington** (LAR) — YPRR 2.46→0.85 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (89th)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (0th), Red zone targets (volume) (0th), Success rate (2nd), Out wide (yds/route) (4th), Separation (step sep at catch pt) (6th)  

**Jaylin Lane** (WAS)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (91st), Deep routes (yds/route) (81st), vs Man coverage (YPRR) (79th)  
&nbsp;&nbsp;✗ Struggles: vs Zone coverage (YPRR) (2nd), Drop rate (lower=better) (3rd), QB rating when targeted (3rd), Short routes (yds/route) (3rd), Contested catch rate (23rd)  

**Khalil Shakir** (BUF) — YPRR 2.2→1.8 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (97th), Out wide (yds/route) (83rd), vs Zone coverage (YPRR) (82nd), Overall YPRR (73rd), vs Zone (yds/zone route, FTN) (72nd)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (1st), Deep routes (yds/route) (5th), Overall efficiency (DVOA) (23rd), Red zone TD rate (TD/target) (23rd), Contested catch rate (30th)  

**Chimere Dike** (TEN)  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (75th), Yards after catch / reception (69th), Drop rate (lower=better) (68th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (10th), Deep routes (yds/route) (12th), vs Zone (yds/zone route, FTN) (16th), Overall YPRR (18th), Out wide (yds/route) (22nd)  

**Roman Wilson** (PIT)  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (72nd)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (1st), From slot (yds/route) (2nd), vs Zone coverage (YPRR) (3rd), vs Zone (yds/zone route, FTN) (6th), Overall YPRR (21st)  

**Calvin Austin III** (NYG) — YPRR 1.41→1.15 ▼  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (67th)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (7th), vs Zone (yds/zone route, FTN) (14th), vs Zone coverage (YPRR) (16th), Red zone targets (volume) (17th), Separation (step sep at catch pt) (17th)  

**Cedric Tillman** (CLE) — YPRR 1.22→0.85 ▼  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (72nd)  
&nbsp;&nbsp;✗ Struggles: Out wide (yds/route) (2nd), Overall YPRR (6th), vs Zone (yds/zone route, FTN) (7th), Success rate (7th), Red zone targets (volume) (12th)  

**Rashid Shaheed** (SEA) — YPRR 2.04→1.36 ▼  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (100th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (11th), Overall efficiency (DVOA) (19th), Contested catch rate (21st), QB rating when targeted (24th), Short routes (yds/route) (24th)  

**Justin Jefferson** (MIN) — YPRR 2.43→1.88 ▼  
&nbsp;&nbsp;✓ Excels: Success rate (95th), Short routes (yds/route) (94th), Red zone targets (volume) (93rd), vs Zone coverage (YPRR) (92nd), vs Zone (yds/zone route, FTN) (89th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (1st), QB rating when targeted (5th), Deep ball (yds/deep target) (6th), Red zone TD rate (TD/target) (14th), Overall efficiency (DVOA) (18th)  

**Joshua Palmer** (BUF) — YPRR 1.49→1.28 ▼  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (65th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (3rd), Red zone TD rate (TD/target) (3rd), QB rating when targeted (8th), Success rate (9th), Yards after catch / reception (11th)  

**Travis Hunter** (JAX)  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (74th), vs Man coverage (YPRR) (70th)  
&nbsp;&nbsp;✗ Struggles: Short routes (yds/route) (8th), vs Man (yds/man route, FTN) (8th), Avg depth of target (aDOT) (12th), Overall efficiency (DVOA) (16th), Success rate (17th)  

**Kyle Williams** (NE)  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (66th)  
&nbsp;&nbsp;✗ Struggles: Overall YPRR (15th), vs Zone (yds/zone route, FTN) (17th), vs Zone coverage (YPRR) (19th), Deep ball (yds/deep target) (20th), Separation (step sep at catch pt) (23rd)  

**Emeka Egbuka** (TB)  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (82nd), Deep routes (yds/route) (82nd), Separation (step sep at catch pt) (79th), vs Zone coverage (YPRR) (79th), Success rate (75th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (4th), Contested catch rate (10th), Overall efficiency (DVOA) (15th), Drop rate (lower=better) (17th), vs Man coverage (YPRR) (18th)  

**Wan'Dale Robinson** (TEN) — YPRR 1.21→1.87 ▲  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (92nd), Success rate (90th), Deep ball (yds/deep target) (88th), vs Zone (yds/zone route, FTN) (84th), vs Zone coverage (YPRR) (80th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (7th), Contested catch rate (12th), Overall efficiency (DVOA) (14th), Avg depth of target (aDOT) (20th)  

**Malik Nabers** (NYG) — YPRR 2.17→2.02 ▼  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (98th), vs Zone (yds/zone route, FTN) (93rd), vs Zone coverage (YPRR) (88th), Overall YPRR (84th), From slot (yds/route) (82nd)  
&nbsp;&nbsp;✗ Struggles: Success rate (8th), Overall efficiency (DVOA) (12th), vs Man (yds/man route, FTN) (15th), Red zone targets (volume) (18th), Separation (step sep at catch pt) (18th)  

**John Metchie III** (CAR) — YPRR 1.07→1.07 –  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (86th), vs Man (yds/man route, FTN) (85th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (6th), vs Zone coverage (YPRR) (7th), vs Zone (yds/zone route, FTN) (8th), Overall efficiency (DVOA) (12th), Out wide (yds/route) (15th)  

**JuJu Smith-Schuster** (NYG) — YPRR 0.97→0.89 –  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (88th), Drop rate (lower=better) (79th)  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (1st), Avg depth of target (aDOT) (3rd), Overall YPRR (10th), vs Zone coverage (YPRR) (35th)  

**Marvin Mims Jr.** (DEN) — YPRR 2.37→1.4 ▼  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (93rd), vs Man coverage (YPRR) (92nd), Yards after catch / reception (87th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (6th), Overall efficiency (DVOA) (10th), Deep ball (yds/deep target) (16th), Separation (step sep at catch pt) (19th), Success rate (19th)  

**Rashod Bateman** (BAL) — YPRR 1.72→0.7 ▼  
&nbsp;&nbsp;✗ Struggles: vs Zone (yds/zone route, FTN) (0th), Overall YPRR (3rd), vs Zone coverage (YPRR) (4th), Out wide (yds/route) (5th), Overall efficiency (DVOA) (9th)  

**Ja'Kobi Lane** (BAL)  
&nbsp;&nbsp;✗ Struggles: Success rate (1st), Red zone targets (volume) (1st), Overall efficiency (DVOA) (8th), Separation (step sep at catch pt) (10th), vs Zone (yds/zone route, FTN) (21st)  

**Treylon Burks** (WAS)  
&nbsp;&nbsp;✗ Struggles: Overall YPRR (8th), Out wide (yds/route) (10th), vs Zone (yds/zone route, FTN) (12th), vs Man coverage (YPRR) (20th), vs Man (yds/man route, FTN) (21st)  

**Isaiah Bond** (CLE)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (94th), Deep routes (yds/route) (88th)  
&nbsp;&nbsp;✗ Struggles: vs Zone (yds/zone route, FTN) (3rd), Success rate (3rd), Out wide (yds/route) (4th), vs Zone coverage (YPRR) (6th), QB rating when targeted (7th)  

**Malik Washington** (MIA) — YPRR 0.86→0.86 –  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (91st), Yards after catch / reception (86th), Contested catch rate (76th)  
&nbsp;&nbsp;✗ Struggles: Deep routes (yds/route) (0th), vs Man (yds/man route, FTN) (4th), Avg depth of target (aDOT) (4th), Overall efficiency (DVOA) (6th), Out wide (yds/route) (8th)  

**Isaac TeSlaa** (DET)  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (100th), Contested catch rate (78th)  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (3rd), From slot (yds/route) (5th), Overall YPRR (5th), vs Zone (yds/zone route, FTN) (9th), vs Man (yds/man route, FTN) (10th)  

**Xavier Legette** (CAR) — YPRR 1.19→0.88 ▼  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (85th), Deep ball (yds/deep target) (81st)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (4th), Short routes (yds/route) (5th), Overall efficiency (DVOA) (5th), Overall YPRR (10th), QB rating when targeted (13th)  

**Olamide Zaccheaus** (ATL) — YPRR 1.45→0.92 ▼  
&nbsp;&nbsp;✓ Excels: Contested catch rate (93rd), Red zone targets (volume) (67th)  
&nbsp;&nbsp;✗ Struggles: Overall efficiency (DVOA) (4th), Avg depth of target (aDOT) (7th), vs Man coverage (YPRR) (7th), Out wide (yds/route) (7th), Overall YPRR (11th)  

**Jalen Tolbert** (MIA) — YPRR 1.1→0.77 ▼  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (2nd), From slot (yds/route) (3rd), Overall YPRR (4th), vs Man coverage (YPRR) (4th), Deep routes (yds/route) (6th)  

**Jerry Jeudy** (CLE) — YPRR 1.72→1.02 ▼  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (0th), QB rating when targeted (1st), Overall efficiency (DVOA) (3rd), Drop rate (lower=better) (6th), vs Zone coverage (YPRR) (8th)  

**Jalen McMillan** (TB)  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (70th), vs Zone coverage (YPRR) (70th)  

**Jahdae Walker** (CHI)  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (75th), vs Zone coverage (YPRR) (73rd)  

**Darnell Mooney** (NYG) — YPRR 1.88→0.97 ▼  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (84th)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (0th), Short routes (yds/route) (1st), Overall efficiency (DVOA) (2nd), Deep ball (yds/deep target) (3rd), From slot (yds/route) (4th)  

**Jahan Dotson** (ATL) — YPRR 0.55→0.6 –  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (96th), Avg depth of target (aDOT) (93rd), Deep ball (yds/deep target) (74th)  
&nbsp;&nbsp;✗ Struggles: From slot (yds/route) (0th), vs Man coverage (YPRR) (2nd), Overall YPRR (2nd), Short routes (yds/route) (2nd), vs Zone coverage (YPRR) (3rd)  

**Adonai Mitchell** (NYJ) — YPRR 1.51→1.46 –  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (92nd), Deep routes (yds/route) (72nd)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (0th), Overall efficiency (DVOA) (1st), QB rating when targeted (2nd), Drop rate (lower=better) (5th), From slot (yds/route) (8th)  

**Dont'e Thornton Jr.** (LV)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (97th)  
&nbsp;&nbsp;✗ Struggles: vs Zone coverage (YPRR) (0th), Drop rate (lower=better) (0th), QB rating when targeted (0th), Deep ball (yds/deep target) (0th), Overall YPRR (1st)  

**Nick Westbrook-Ikhine** (IND) — YPRR 1.14→0.4 ▼  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (0th), Overall YPRR (0th), vs Zone coverage (YPRR) (1st), Deep routes (yds/route) (4th), Short routes (yds/route) (21st)  

**Christian Kirk** (SF) — YPRR 1.72→1.16 ▼  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (71st), Yards after catch / reception (67th)  
&nbsp;&nbsp;✗ Struggles: Overall efficiency (DVOA) (0th), vs Man (yds/man route, FTN) (6th), QB rating when targeted (6th), Contested catch rate (7th), Avg depth of target (aDOT) (11th)  


## Tight Ends (50)

**Dalton Kincaid** (BUF) — YPRR 1.54→2.7 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (100th), Overall YPRR (100th), Out wide (yds/route) (100th), vs Zone (yds/zone route, FTN) (100th), Overall efficiency (DVOA) (100th)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (25th)  

**George Kittle** (SF) — YPRR 2.62→2.11 ▼  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (98th), vs Man (yds/man route, FTN) (98th), Overall efficiency (DVOA) (98th), Contested catch rate (97th), QB rating when targeted (96th)  
&nbsp;&nbsp;✗ Struggles: Out wide (yds/route) (20th), Yards after catch / reception (34th)  

**Darren Waller** (FA)  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (100th), Avg depth of target (aDOT) (98th), Drop rate (lower=better) (96th), Overall efficiency (DVOA) (96th), QB rating when targeted (93rd)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (7th), Success rate (16th), vs Zone coverage (YPRR) (23rd), Short routes (yds/route) (28th), Red zone targets (volume) (29th)  

**Sam LaPorta** (DET) — YPRR 1.56→2.0 ▲  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (100th), vs Zone (yds/zone route, FTN) (94th), Overall efficiency (DVOA) (93rd), Overall YPRR (92nd), Yards after catch / reception (91st)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (16th), Avg depth of target (aDOT) (31st)  

**Tucker Kraft** (GB) — YPRR 1.55→2.33 ▲  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (100th), vs Man (QB rating when targeted) (100th), Yards after catch / reception (100th), QB rating when targeted (100th), From slot (yds/route) (100th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (9th), vs Zone (yds/zone route, FTN) (10th), Out wide (yds/route) (11th), Drop rate (lower=better) (20th)  

**Jake Tonges** (SF)  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (95th), Overall efficiency (DVOA) (89th), Drop rate (lower=better) (84th), QB rating when targeted (71st)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (6th), vs Man (yds/man route, FTN) (17th), Red zone targets (volume) (27th), From slot (yds/route) (27th), Success rate (33rd)  

**Oronde Gadsden II** (LAC)  
&nbsp;&nbsp;✓ Excels: Deep ball (yds/deep target) (100th), Deep routes (yds/route) (100th), vs Zone coverage (YPRR) (94th), Contested catch rate (90th), Out wide (yds/route) (89th)  
&nbsp;&nbsp;✗ Struggles: Short routes (yds/route) (4th), Drop rate (lower=better) (9th), vs Man coverage (YPRR) (21st), Red zone TD rate (TD/target) (30th), Yards after catch / reception (32nd)  

**Brenton Strange** (JAX) — YPRR 1.49→1.58 ▲  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (98th), Overall efficiency (DVOA) (84th), vs Man coverage (YPRR) (83rd), Short routes (yds/route) (78th), vs Zone (yds/zone route, FTN) (76th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (28th), Deep routes (yds/route) (35th)  

**Colston Loveland** (CHI)  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (96th), From slot (yds/route) (94th), Avg depth of target (aDOT) (93rd), vs Zone coverage (YPRR) (90th), Overall YPRR (90th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (25th), Contested catch rate (26th)  

**Pat Freiermuth** (PIT) — YPRR 1.42→1.41 –  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (92nd), Drop rate (lower=better) (87th), Yards after catch / reception (86th), Overall efficiency (DVOA) (80th), vs Zone coverage (YPRR) (73rd)  
&nbsp;&nbsp;✗ Struggles: Out wide (yds/route) (14th)  

**Dawson Knox** (BUF) — YPRR 1.04→1.35 ▲  
&nbsp;&nbsp;✓ Excels: Overall efficiency (DVOA) (78th), vs Zone (yds/zone route, FTN) (71st), Red zone targets (volume) (71st), Red zone TD rate (TD/target) (70th), Avg depth of target (aDOT) (69th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (0th), Separation (step sep at catch pt) (6th), Short routes (yds/route) (13th), Drop rate (lower=better) (18th), Out wide (yds/route) (23rd)  

**Brock Bowers** (LV) — YPRR 2.02→1.7 ▼  
&nbsp;&nbsp;✓ Excels: vs Man (yds/man route, FTN) (94th), Out wide (yds/route) (91st), Short routes (yds/route) (89th), Red zone targets (volume) (89th), Contested catch rate (84th)  

**Greg Dulcich** (MIA) — YPRR 0.25→2.31 ▲  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (98th), From slot (yds/route) (98th), Yards after catch / reception (98th), vs Zone coverage (YPRR) (96th), Overall YPRR (96th)  
&nbsp;&nbsp;✗ Struggles: Out wide (yds/route) (4th), Success rate (9th), Red zone targets (volume) (22nd), Red zone TD rate (TD/target) (22nd), Avg depth of target (aDOT) (27th)  

**Hunter Henry** (NE) — YPRR 1.39→1.54 ▲  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (93rd), Short routes (yds/route) (91st), Success rate (89th), vs Zone coverage (YPRR) (85th), vs Man (yds/man route, FTN) (81st)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (27th), Red zone TD rate (TD/target) (32nd), Deep routes (yds/route) (33rd)  

**Dallas Goedert** (PHI) — YPRR 2.18→1.34 ▼  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (98th), QB rating when targeted (91st), vs Man (QB rating when targeted) (90th), Red zone targets (volume) (82nd), Success rate (78th)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (0th), Short routes (yds/route) (6th), vs Man (yds/man route, FTN) (19th), Yards after catch / reception (20th), vs Zone coverage (YPRR) (31st)  

**Colby Parkinson** (LAR) — YPRR 1.0→1.8 ▲  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (96th), Red zone targets (volume) (96th), Yards after catch / reception (93rd), Overall YPRR (88th), QB rating when targeted (82nd)  
&nbsp;&nbsp;✗ Struggles: From slot (yds/route) (4th), Drop rate (lower=better) (4th), Deep routes (yds/route) (5th), Contested catch rate (16th), Avg depth of target (aDOT) (24th)  

**Travis Kelce** (KC) — YPRR 1.49→1.47 –  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (100th), Success rate (96th), From slot (yds/route) (79th), Yards after catch / reception (73rd), Out wide (yds/route) (73rd)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (0th), Deep routes (yds/route) (12th), vs Man (QB rating when targeted) (19th), Contested catch rate (19th), Drop rate (lower=better) (22nd)  

**Mike Gesicki** (CIN) — YPRR 1.58→1.22 ▼  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (98th), Avg depth of target (aDOT) (96th), Deep routes (yds/route) (72nd)  
&nbsp;&nbsp;✗ Struggles: QB rating when targeted (2nd), Short routes (yds/route) (2nd), Yards after catch / reception (2nd), vs Man coverage (YPRR) (17th), Red zone targets (volume) (24th)  

**Trey McBride** (ARI) — YPRR 2.14→1.78 ▼  
&nbsp;&nbsp;✓ Excels: Success rate (100th), Red zone targets (volume) (100th), Separation (step sep at catch pt) (94th), Drop rate (lower=better) (91st), vs Zone (yds/zone route, FTN) (90th)  
&nbsp;&nbsp;✗ Struggles: vs Man (QB rating when targeted) (24th), Deep ball (yds/deep target) (29th)  

**Tyler Higbee** (LAR)  
&nbsp;&nbsp;✓ Excels: Deep routes (yds/route) (98th), QB rating when targeted (87th), vs Zone (yds/zone route, FTN) (86th), Yards after catch / reception (80th), vs Zone coverage (YPRR) (67th)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (12th), Drop rate (lower=better) (13th), Success rate (13th), Separation (step sep at catch pt) (27th)  

**AJ Barner** (SEA) — YPRR 1.13→1.35 ▲  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (89th), Contested catch rate (87th), vs Man (yds/man route, FTN) (83rd), QB rating when targeted (78th), Red zone TD rate (TD/target) (78th)  
&nbsp;&nbsp;✗ Struggles: From slot (yds/route) (6th), Deep routes (yds/route) (9th), vs Zone coverage (YPRR) (15th), vs Zone (yds/zone route, FTN) (16th), Avg depth of target (aDOT) (22nd)  

**Kyle Pitts Sr.** (ATL) — YPRR 1.33→1.71 ▲  
&nbsp;&nbsp;✓ Excels: Success rate (98th), Separation (step sep at catch pt) (96th), vs Man coverage (YPRR) (94th), vs Man (yds/man route, FTN) (92nd), Short routes (yds/route) (83rd)  
&nbsp;&nbsp;✗ Struggles: Deep ball (yds/deep target) (14th), Yards after catch / reception (30th)  

**Juwan Johnson** (NO) — YPRR 1.34→1.69 ▲  
&nbsp;&nbsp;✓ Excels: Success rate (91st), From slot (yds/route) (88th), vs Zone (yds/zone route, FTN) (80th), Overall YPRR (75th), Avg depth of target (aDOT) (71st)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (24th), Short routes (yds/route) (30th), Red zone targets (volume) (31st), vs Man (QB rating when targeted) (33rd)  

**Charlie Kolar** (LAC)  
&nbsp;&nbsp;✓ Excels: vs Zone (yds/zone route, FTN) (67th)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (0th), vs Man (yds/man route, FTN) (2nd)  

**T.J. Hockenson** (MIN) — YPRR 1.56→1.05 ▼  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (67th)  
&nbsp;&nbsp;✗ Struggles: Overall YPRR (8th), vs Man coverage (YPRR) (8th), Avg depth of target (aDOT) (16th), Out wide (yds/route) (18th), vs Zone (yds/zone route, FTN) (20th)  

**Luke Musgrave** (GB)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (78th)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (0th), Out wide (yds/route) (2nd), Success rate (4th), vs Zone coverage (YPRR) (10th), Yards after catch / reception (14th)  

**Dalton Schultz** (HOU) — YPRR 1.08→1.57 ▲  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (98th), Success rate (93rd), Out wide (yds/route) (93rd), Drop rate (lower=better) (89th), vs Zone coverage (YPRR) (77th)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (10th), Deep routes (yds/route) (14th), vs Man (QB rating when targeted) (14th), vs Man coverage (YPRR) (32nd)  

**Cole Kmet** (CHI) — YPRR 0.91→0.96 –  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (87th)  
&nbsp;&nbsp;✗ Struggles: vs Zone (yds/zone route, FTN) (4th), Overall YPRR (6th), Short routes (yds/route) (15th), QB rating when targeted (16th), vs Zone coverage (YPRR) (17th)  

**David Njoku** (LAC) — YPRR 1.33→1.06 ▼  
&nbsp;&nbsp;✓ Excels: Contested catch rate (94th), Red zone TD rate (TD/target) (88th)  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (4th), vs Man (yds/man route, FTN) (8th), Overall YPRR (12th), From slot (yds/route) (17th), Success rate (20th)  

**Zach Ertz** (FA) — YPRR 1.32→1.37 –  
&nbsp;&nbsp;✓ Excels: Red zone TD rate (TD/target) (92nd), Separation (step sep at catch pt) (90th), Avg depth of target (aDOT) (89th), vs Zone (yds/zone route, FTN) (82nd), vs Zone coverage (YPRR) (79th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (2nd), Yards after catch / reception (4th), vs Man (QB rating when targeted) (5th), Short routes (yds/route) (9th), vs Man coverage (YPRR) (15th)  

**Theo Johnson** (NYG) — YPRR 0.9→1.24 ▲  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (88th), vs Man coverage (YPRR) (87th), Avg depth of target (aDOT) (82nd), Red zone targets (volume) (78th), vs Man (yds/man route, FTN) (75th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (0th), vs Zone (yds/zone route, FTN) (12th), Short routes (yds/route) (17th), vs Zone coverage (YPRR) (21st), QB rating when targeted (22nd)  

**Tyler Warren** (IND)  
&nbsp;&nbsp;✓ Excels: vs Zone coverage (YPRR) (92nd), Red zone targets (volume) (91st), Yards after catch / reception (89th), Success rate (87th), vs Zone (yds/zone route, FTN) (69th)  
&nbsp;&nbsp;✗ Struggles: From slot (yds/route) (21st), Contested catch rate (23rd), Red zone TD rate (TD/target) (25th), vs Man coverage (YPRR) (26th), QB rating when targeted (31st)  

**Terrance Ferguson** (LAR)  
&nbsp;&nbsp;✓ Excels: Avg depth of target (aDOT) (100th), Deep routes (yds/route) (93rd), vs Man (yds/man route, FTN) (90th), vs Man coverage (YPRR) (81st), Deep ball (yds/deep target) (71st)  
&nbsp;&nbsp;✗ Struggles: Contested catch rate (3rd), vs Zone (yds/zone route, FTN) (6th), Short routes (yds/route) (11th), QB rating when targeted (11th), Separation (step sep at catch pt) (12th)  

**Harold Fannin Jr.** (CLE)  
&nbsp;&nbsp;✓ Excels: Short routes (yds/route) (85th), Out wide (yds/route) (82nd), vs Zone coverage (YPRR) (81st), Separation (step sep at catch pt) (81st), Red zone TD rate (TD/target) (80th)  
&nbsp;&nbsp;✗ Struggles: Overall efficiency (DVOA) (31st), Contested catch rate (32nd)  

**Tommy Tremble** (CAR) — YPRR 0.89→0.88 –  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (84th)  
&nbsp;&nbsp;✗ Struggles: Separation (step sep at catch pt) (2nd), Avg depth of target (aDOT) (2nd), Overall YPRR (4th), Red zone targets (volume) (7th), Out wide (yds/route) (7th)  

**Cade Otton** (TB) — YPRR 1.31→1.08 ▼  
&nbsp;&nbsp;✓ Excels: Drop rate (lower=better) (78th), Success rate (67th)  
&nbsp;&nbsp;✗ Struggles: Deep routes (yds/route) (7th), vs Man (QB rating when targeted) (10th), Red zone targets (volume) (11th), Red zone TD rate (TD/target) (12th), vs Man coverage (YPRR) (13th)  

**Isaiah Likely** (NYG) — YPRR 1.71→1.29 ▼  
&nbsp;&nbsp;✓ Excels: Out wide (yds/route) (96th), Short routes (yds/route) (87th), Avg depth of target (aDOT) (73rd), Drop rate (lower=better) (71st), vs Man coverage (YPRR) (70th)  
&nbsp;&nbsp;✗ Struggles: Success rate (7th), vs Zone coverage (YPRR) (12th), Deep routes (yds/route) (16th), Red zone TD rate (TD/target) (20th), Red zone targets (volume) (20th)  

**Darnell Washington** (PIT) — YPRR 1.26→1.72 ▲  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (96th), Overall YPRR (81st), Out wide (yds/route) (68th), Short routes (yds/route) (67th), vs Man coverage (YPRR) (66th)  
&nbsp;&nbsp;✗ Struggles: Drop rate (lower=better) (7th), Red zone TD rate (TD/target) (10th), Separation (step sep at catch pt) (10th), QB rating when targeted (18th), Avg depth of target (aDOT) (20th)  

**Ben Sinnott** (WAS) — YPRR 0.46→1.09 ▲  
&nbsp;&nbsp;✓ Excels: vs Man coverage (YPRR) (98th), vs Man (yds/man route, FTN) (85th)  
&nbsp;&nbsp;✗ Struggles: vs Zone (yds/zone route, FTN) (2nd), vs Zone coverage (YPRR) (2nd), Separation (step sep at catch pt) (8th), From slot (yds/route) (10th), Overall YPRR (21st)  

**Mark Andrews** (BAL) — YPRR 1.88→1.23 ▼  
&nbsp;&nbsp;✓ Excels: Separation (step sep at catch pt) (92nd), vs Man coverage (YPRR) (85th), Red zone targets (volume) (84th), vs Man (yds/man route, FTN) (77th), Avg depth of target (aDOT) (76th)  
&nbsp;&nbsp;✗ Struggles: Yards after catch / reception (0th), vs Zone coverage (YPRR) (4th), vs Zone (yds/zone route, FTN) (18th), Overall efficiency (DVOA) (20th), QB rating when targeted (24th)  

**Chig Okonkwo** (WAS)  
&nbsp;&nbsp;✓ Excels: From slot (yds/route) (83rd), Separation (step sep at catch pt) (71st)  
&nbsp;&nbsp;✗ Struggles: Red zone targets (volume) (9th), Out wide (yds/route) (9th), Overall efficiency (DVOA) (18th), Deep routes (yds/route) (26th), Short routes (yds/route) (33rd)  

**Elijah Arroyo** (SEA)  
&nbsp;&nbsp;✗ Struggles: From slot (yds/route) (0th), Short routes (yds/route) (0th), Separation (step sep at catch pt) (4th), vs Man (yds/man route, FTN) (10th), Overall YPRR (17th)  

**Gunnar Helm** (TEN)  
&nbsp;&nbsp;✓ Excels: Contested catch rate (81st), Deep routes (yds/route) (74th), From slot (yds/route) (71st), vs Zone coverage (YPRR) (69th)  
&nbsp;&nbsp;✗ Struggles: Red zone TD rate (TD/target) (8th), Overall efficiency (DVOA) (16th), Yards after catch / reception (16th), Separation (step sep at catch pt) (21st), vs Man coverage (YPRR) (23rd)  

**Noah Fant** (NO) — YPRR 1.29→1.35 –  
&nbsp;&nbsp;✓ Excels: Short routes (yds/route) (94th), QB rating when targeted (84th), Drop rate (lower=better) (80th), vs Zone coverage (YPRR) (75th), vs Zone (yds/zone route, FTN) (74th)  
&nbsp;&nbsp;✗ Struggles: Avg depth of target (aDOT) (0th), Out wide (yds/route) (0th), vs Man coverage (YPRR) (2nd), From slot (yds/route) (2nd), Deep routes (yds/route) (2nd)  

**Michael Mayer** (LV) — YPRR 0.67→1.48 ▲  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (75th), Short routes (yds/route) (74th), vs Zone coverage (YPRR) (71st), Deep routes (yds/route) (70th), vs Man coverage (YPRR) (68th)  
&nbsp;&nbsp;✗ Struggles: QB rating when targeted (0th), Avg depth of target (aDOT) (7th), Overall efficiency (DVOA) (11th), Red zone targets (volume) (13th), Red zone TD rate (TD/target) (15th)  

**Jake Ferguson** (DAL) — YPRR 1.27→1.2 –  
&nbsp;&nbsp;✓ Excels: Red zone targets (volume) (98th), Separation (step sep at catch pt) (85th), Success rate (80th), QB rating when targeted (69th), Out wide (yds/route) (66th)  
&nbsp;&nbsp;✗ Struggles: Overall efficiency (DVOA) (9th), Avg depth of target (aDOT) (11th), Yards after catch / reception (18th), Overall YPRR (23rd), From slot (yds/route) (23rd)  

**Ja'Tavion Sanders** (CAR) — YPRR 1.09→0.83 ▼  
&nbsp;&nbsp;✗ Struggles: vs Man coverage (YPRR) (0th), Red zone TD rate (TD/target) (0th), Deep routes (yds/route) (0th), Overall YPRR (2nd), Success rate (2nd)  

**Mason Taylor** (NYJ)  
&nbsp;&nbsp;✓ Excels: Contested catch rate (100th), Short routes (yds/route) (70th)  
&nbsp;&nbsp;✗ Struggles: vs Man (yds/man route, FTN) (0th), Overall efficiency (DVOA) (4th), Red zone TD rate (TD/target) (5th), vs Man coverage (YPRR) (6th), From slot (yds/route) (8th)  

**Evan Engram** (DEN) — YPRR 1.51→1.21 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (77th), Short routes (yds/route) (65th)  
&nbsp;&nbsp;✗ Struggles: Overall efficiency (DVOA) (2nd), Red zone TD rate (TD/target) (2nd), Avg depth of target (aDOT) (4th), QB rating when targeted (7th), From slot (yds/route) (15th)  

**Noah Gray** (KC) — YPRR 1.29→0.7 ▼  
&nbsp;&nbsp;✓ Excels: Yards after catch / reception (66th)  
&nbsp;&nbsp;✗ Struggles: vs Zone coverage (YPRR) (0th), Overall YPRR (0th), vs Zone (yds/zone route, FTN) (0th), Overall efficiency (DVOA) (0th), Success rate (0th)  
